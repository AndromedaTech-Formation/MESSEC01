#!/usr/bin/env bash

# SOURCES POUR LE TP WordPress MFA - mise en oeuvre de l'authentification double facteur


# variables
VERT="\e[32m"
CYAN="\e[36m"
JAUNE="\e[33m"
ROUGE="\e[31m"
FLASH="\e[1;5;33m"
NC="\e[0m"

# Préparation de Docker

cd /var/tp5.1
apt-get update
apt-get install ca-certificates curl -y
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc


# ajout du source.list Docker
rm /etc/apt/sources.list.d/docker.sources
tee /etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/debian
Suites: $(. /etc/os-release && echo "$VERSION_CODENAME")
Components: stable
Signed-By: /etc/apt/keyrings/docker.asc
EOF

apt-get update && apt-get install docker-ce -y

docker compose up -d && docker ps -a

echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo "*********************************************************"
echo -e "************   ${VERT}INSTALLATION TERMINEE   ${NC}******************"
echo "*********************************************************"
echo ""
echo ""
echo "Vous pouvez maintenant ouvrir votre navigateur et vous rendre à l'adresse :"
echo -e "${ROUGE} ==> ${CYAN} http://localhost:1337 ${NC}"
echo "et suivez les instructions données dans l'énoncé de l'exercice"
echo ""
exit

