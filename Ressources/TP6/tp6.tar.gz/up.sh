#!/bin/bash

# =================================================================
# Script de configuration automatique Serveur MATRIX avec back-end SYNAPSE et client Web ELEMENT
# Cours MESSEC01 : Concept de messagerie sécurisée et gestion des droits d'accès
#
# TP n°6 : Installation d'un serveur Matrix
#
# ==========================================================

# ========= COULEURS ===========
VERT="\e[32m"
CYAN="\e[36m"
JAUNE="\e[33m"
ROUGE="\e[31m"
FLASH="\e[1;5;33m"
NC="\e[0m"

# Vérification que le script est exécuté en root
clear
if [[ $EUID -ne 0 ]]; then
    echo "Veuillez exécuter ce script en tant que root."
    exit 1
fi

# ================================
# Demande des informations de base
# ================================

clear
echo -e "${NC}${CYAN} Script de configuration automatique ${JAUNE}serveur MATRIX avec back-end SYNAPSE et client Web ELEMENT"
echo -e "${NC} Cours MESSEC01 : Messagerie securisée et contrôle d'accès"
echo -e "${NC} https://github.com/AndromedaTech-Formation/MESSEC01"
echo ""
echo -e " ${JAUNE}TP n°6 : Installation d'un serveur Matrix"
echo " Ce script est à utiliser sur une machine en Debian 13"
echo -e "${ROUGE}${FLASH}AVERTISSEMENT"
echo -e "${NC}${ROUGE}    Usage strictement pédagogique"
echo -e "    Ce script ne doit pas être utilisé en PRODUCTION connecté à Internet"
echo ""
echo -e "${VERT} Indiquez votre nom de domaine (FQDN) :${NC}"
echo -e "exemple : abri207.tech"
read -p " $(domainname) :" NEW_DOMAIN
echo -e "${NC} > Le FQDN suivant sera utilisé : ${VERT} $NEW_DOMAIN"
read -p " Lancer le script ? :"
echo ""
echo ""
echo -e "${NC}"

HOSTNAME=$(hostname)

echo -e "${CYAN} >>>>>> PREPARATION DU SYSTEME... ${NC}"
apt-get update
apt install ca-certificates curl -y

#echo -e "${CYAN} >>>>>> INSTALLATION DE DOCKER... ${NC}"
#curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh
echo -e "${CYAN} >>>>>> VERIFICATION DE DOCKER... ${NC}"

# ================================
# Fonction de vérification Docker
# ================================
check_docker_installed() {
    # Vérifie si le binaire docker existe
    if command -v docker &> /dev/null; then
        # Vérifie si le service docker est actif
        if systemctl is-active --quiet docker; then
            echo -e "${VERT}Docker est déjà installé et actif${NC}"
            return 0
        else
            echo -e "${JAUNE}Docker est installé mais le service n'est pas actif${NC}"
            echo -e "${CYAN}Démarrage du service Docker...${NC}"
            systemctl start docker
            systemctl enable docker
            return 0
        fi
    else
        return 1
    fi
}

# ================================
# Installation de Docker si nécessaire
# ================================

if check_docker_installed; then
    echo -e "${VERT}Docker est prêt à être utilisé${NC}"
else
    echo -e "${CYAN} >>>>>> INSTALLATION DE DOCKER... ${NC}"
    curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh

    # Vérification post-installation
    if ! check_docker_installed; then
        echo -e "${ROUGE}Échec de l'installation de Docker${NC}"
        exit 1
    fi
fi


echo -e "${CYAN} >>>>>> AFFICHAGE DES VERSIONS DE DOCKER ET DOCKER-COMPOSE ${NC}"
# affichage des versions installées
docker --version
docker compose version

echo -e "${CYAN} >>>>>> PRECONFIGURATION DU SERVEUR ${JAUNE}MATRIX... ${NC}"
# création du dossier Matrix-server dédié à l'instance
mkdir -p ~/matrix-server
cd ~/matrix-server

echo -e "${CYAN} >>>>>> ECRITURE DU FICHIER ${JAUNE}docker-compose.yml... ${NC}"

# Ecriture du fichier docker-compose.yml 
cat > docker-compose.yml <<EOF

services:

  synapse:
    image: matrixdotorg/synapse:latest
    container_name: matrix-synapse
    restart: no
    volumes:
      - ./synapse:/data
    ports:
      - "8008:8008"
    environment:
      - SYNAPSE_SERVER_NAME=$NEW_DOMAIN
      - SYNAPSE_REPORT_STATS=no

  element:
    image: vectorim/element-web:latest
    container_name: element-web
    restart: no
    ports:
      - "8080:80"
    volumes:
      - ./config.json:/app/config.json
EOF

echo -e "${CYAN} >>>>>> ECRITURE DU FICHIER ${JAUNE}config.json ${CYAN}DE MATRIX... ${NC}"
# Ecriture du fichier config.json
cat > config.json <<EOF
{
  "default_server_config": {
    "m.homeserver": {
      "base_url": "http://$NEW_DOMAIN:8008",
      "server_name": "$NEW_DOMAIN"
    }
  }
}
EOF


echo -e "${CYAN} >>>>>> GENERATION DE LA CONFIGURATION DE ${JAUNE}SYNAPSE... ${NC}"
# génération de la configuration Synapse (avec configuration du nom de domaine)
docker run -it --rm -v $(pwd)/synapse:/data -e SYNAPSE_SERVER_NAME=$NEW_DOMAIN -e SYNAPSE_REPORT_STATS=no matrixdotorg/synapse:latest generate

echo -e "${CYAN} >>>>>> DEMARRAGE DES CONTENEURS... ${NC}"
# Démarrage des conteneurs
docker compose up -d && docker ps -a


echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo "*********************************************************"
echo -e "************   ${VERT}INSTALLATION TERMINEE   ${NC}******************"
echo "*********************************************************"
echo ""
echo ""
echo -e "Vous pouvez maintenant configurer votre ${VERT}client Element :"
echo -e "${ROUGE} ==> Serveur Matrix ${CYAN} http://$HOSTNAME.$NEW_DOMAIN:8008 ${NC}"
echo -e "${ROUGE} ==> Element (Web) ${CYAN} http://$HOSTNAME.$NEW_DOMAIN:8080 ${NC}"
echo "et suivez les instructions données dans l'énoncé de l'exercice"
echo ""
exit
